import React from "react";

function Addpost(props) {
  return null;
}

export default Addpost;
